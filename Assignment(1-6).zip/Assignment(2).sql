create database assignments_1_6
 use assignments_1_6

--Tasks To Be Performed:

--1. Create a customer table which comprises of these columns: �customer_id�,
---�first_name�, �last_name�, �email�, �address�, �city�,�state�,�zip�

drop table if exists customer
create table customer(customer_id int,first_name varchar(50),
    last_name varchar(50), email nvarchar(50), address nvarchar(50), city varchar(50),state varchar(50),zip int )


--2 insert 5 new records into the table

insert into customer values	
(1001,'Tim','Daya',N'Tday@gmail.com',N'23-street','Hyd','TS',50001),                      
(1002, 'John', 'Jordan', N'john@gmail.com', N'123 Main St', 'New York', 'NY', 10001),
(1003, 'Jane', 'Smith', N'jane@outlook.com', N'456 Elm St', 'Los Angeles', 'CA', 90001),
(1004, 'Garry', 'Johnson', N'alice@yahoo.com', N'789 Oak St', 'San Jose', 'IL', 60001)

--3.select only the �first_name� and �last_name� columns from the customer table

SELECT first_name,LAST_NAME FROM CUSTOMER


--4. Select those records where �first_name� starts with �G� and city is �San Jose�.

SELECT * FROM CUSTOMER WHERE first_name like 'G%' AND CITY='san jose'


--5. Select those records where Email has only �gmail�. 

select * from CUSTOMER WHERE email like '%gmail%'



--6. Select those records where the �last_name� 
-----doesn't end with �A�

select * from CUSTOMER WHERE last_name not like '%a'