﻿--Tasks To Be Performed:

--1. Install MS SQL Server

MS SQL SERVER IS INSTALLED.  

--2. Give the difference between Char and Varchar data type.
 
CHAR is a fixed-length character data type.
If the actual data is shorter than the defined length, 
spaces are padded to the end of the data to fill the remaining space.

VARCHAR is a variable-length character data type.
VARCHAR only uses the amount of storage space needed to store the actual data,
plus two extra bytes to store the length of the data.


--3. Explain the types of SQL Commands. 

Data Manipulation Language (DML) Commands:

DML commands are used to manipulate data stored in the database.
Common DML commands include:
SELECT: Retrieves data from one or more tables.
INSERT: Adds new rows of data into a table.
UPDATE: Modifies existing data in a table.
DELETE: Removes rows of data from a table.

Data Definition Language (DDL) Commands:

DDL commands are used to define and manage the structure of database objects.
Common DDL commands include:
CREATE: Creates new database objects such as tables, indexes, views, or stored procedures.
ALTER: Modifies the structure of existing database objects.
DROP: Deletes database objects such as tables, indexes, views, or stored procedures.
TRUNCATE: Removes all rows from a table while retaining the table structure.

Data Control Language (DCL) Commands:

DCL commands are used to control access to data stored in the database.
Common DCL commands include:
GRANT: Provides users with privileges to access database objects.
REVOKE: Removes privileges from users.

Transaction Control Commands:

Transaction control commands are used to manage transactions in the database.
Common transaction control commands include:
COMMIT: Saves all changes made during the current transaction.
ROLLBACK: Reverts all changes made during the current transaction.
SAVEPOINT: Sets a point within a transaction to which you can later roll back.

Data Query Language (DQL) Commands:

DQL commands are used specifically for querying data from the database.
Common DQL commands include:
SELECT: Retrieves data from one or more tables based on specified criteria.


--4. Explain  NVarchar and Nchar

In SQL, NVARCHAR and NCHAR are data types used to store Unicode character data.
They are similar to VARCHAR and CHAR, respectively, but they support storing Unicode characters,
which allows for storage of characters from multiple character sets, including non-Latin characters 
such as Chinese, Japanese, and Arabic.

example:
DECLARE @text NVARCHAR(100)
SET @text = N'Hello, 你好, مرحبا' --The N prefix before the string indicates that it is a Unicode string.
print(@text)