
use assignments_1_6

--Tasks To Be Performed:

--1. Create an �Orders� table which comprises of these columns: �order_id�,
--�order_date�, �amount�, �customer_id�.

drop table if exists orders
create table orders(order_id int ,order_date date,amount money,customer_id int)


--2. Insert 5 new records. 


insert into orders values(100012,'01/15/2024',23000,1001),
						(102342,'02/10/2024',34000,1002),
						(144132,'02/12/2024',45000,1003),
						(154612,'01/29/2024',2300,1004),
						(103452,'01/01/2024',12000,1005)



--3. Make an inner join on �Customer� and �Orders� tables on the �customer_id� column.

select * from orders o join customer c on o.customer_id=c.customer_id

--4. Make left and right joins on �Customer� and �Orders� tables on the
--�customer_id� column. 

select * from customer c left join orders o on c.customer_id=o.customer_id

select * from customer c right join orders o on c.customer_id=o.customer_id

--5. Make a full outer join on �Customer� and �Orders� table on the �customer_id� column. 

select * from customer c full join orders o on c.customer_id=o.customer_id


--6. Update the �Orders� table and set the amount to be 100 where
--�customer_id� is 1003

update orders set amount=100 where customer_id=1003


